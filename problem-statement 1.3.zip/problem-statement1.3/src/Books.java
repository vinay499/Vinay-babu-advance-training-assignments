
public class Books {
	String book_title;
	double book_price;
	
	public Books(String book_tittle, double book_price)
	{
		this.book_title= book_tittle;
		this.book_price = book_price;
	}
	
	public String getBook_tittle() {
		return book_title;
	}
	public void setBook_tittle(String book_tittle) {
		this.book_title = book_tittle;
	}
	public double getBook_price() {
		return book_price;
	}
	public void setBook_price(double book_price) {
		this.book_price = book_price;
	}
	
	 public void display(){
	      System.out.println("book_title: "+this.book_title);
	      System.out.println("book_price: "+this.book_price);
	      
	   }
	
}



