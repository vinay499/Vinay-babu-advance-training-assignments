
public class Storage {

}
