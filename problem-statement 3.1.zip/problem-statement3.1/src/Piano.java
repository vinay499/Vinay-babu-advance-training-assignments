
public class Piano {

}
