
public class Guitar {

}
