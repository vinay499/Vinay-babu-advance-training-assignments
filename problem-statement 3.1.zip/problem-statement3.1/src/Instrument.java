
public class Instrument {

}
